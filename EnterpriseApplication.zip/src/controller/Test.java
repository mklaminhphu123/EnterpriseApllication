//package controller;
//
//import java.util.Date;
//
//import model.Scanner;
//import model.SimpleDateFormat;
//
//public static void main(String[] args) throws Exception
//{
//    Scanner menu = new Scanner(System.in);
//    int mode = -1;
//
//    while(mode != 0)
//    {
//        System.out.println("Enter 1 to view all current lead");
//        System.out.println("Enter 2 to edit lead");
//        System.out.println("Enter 0 to exit");
//
//        mode = menu.nextInt();
//
//        if (mode == 1)
//        {
//            for (int i = 1; i <= 999; i++)
//            {
//                if (equals(nameList[i],"0") == true || nameList[i] == null)
//                {
//                    break;
//                }
//                else
//                {
//                    System.out.printf("lead_%03d,%s,%td-%tm-%tY,%b,%s,%s,%s%n", n, nameList[i], dobList[i], dobList[i], dobList[i], genderList[i], phoneList[i], emailList[i], addressList[i]);
//                }
//            }
//        }
//        else if (mode == 2 )
//        {
//            Scanner edit = new Scanner(System.in);
//            int editMode = -1;
//
//            while (editMode != 0)
//            {
//                System.out.println("Enter 1 to delete an existed Lead");
//                System.out.println("Enter 2 to update a Lead");
//                System.out.println("Enter 3 to add Leads");
//                System.out.println("Enter 0 to go back to main menu");
//                editMode = edit.nextInt();
//
//                if (editMode == 1)
//                {
//                    Scanner delete = new Scanner(System.in);
//                    System.out.println("Pls, enter the id of the lead you want to delete");
//                    int target = delete.nextInt();
//                    nameList[target] = null;
//                    dobList[target] = null;
//                    genderList[target] = false;
//                    phoneList[target] = null;
//                    emailList[target] = null;
//                    addressList[target] = null;
//                }
//                else if (editMode == 2)
//                {
//                    Scanner update = new Scanner(System.in);
//                    System.out.println("Pls, enter the id of the lead you want to update");
//                    int target2 = update.nextInt();
//
//                    System.out.println("Please update the name: ");
//                    String newName = update.nextLine();
//                    nameList[target2] = newName;
//
//                    System.out.println("Please update the birthdate: ");
//                    String newDOB = update.nextLine();
//                    SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
//                    Date newBDAY = format.parse(newDOB);
//                    dobList[target2] = newBDAY;
//
//                    System.out.println("Please update the gender: ");
//                    boolean newGender = update.nextBoolean();
//                    genderList[target2] = newGender;
//
//                    System.out.println("Please update the phone number: ");
//                    String newPhone = update.nextLine();
//                    phoneList[target2] = newPhone;
//
//                    System.out.println("Please update the email: ");
//                    String newEmail = update.nextLine();
//                    emailList[target2] = newEmail;
//
//                    System.out.println("Please update the address: ");
//                    String newAddress = update.nextLine();
//                    addressList[target2] = newAddress;
//                }
//                else if (editMode == 3)
//                {
//                    Scanner button = new Scanner(System.in);
//                    int end = 1;
//
//                    while (end != 0)
//                    {
//                        System.out.println("Enter 0 to end - Enter 1 to continue");
//                        System.out.println("Do you wish to end now ?");
//                        end = button.nextInt();
//                        if (end == 0)
//                        {
//                            break;
//                        }
//                        else
//                        {
//                            n += 1;
//                            leads();
//                        }
//                    }
//                }
//                else if(editMode == 0)
//                {
//                    break;
//                }
//            }
//        }
//        else if(mode == 0)
//        {
//            break;
//        }
//    }
//}
