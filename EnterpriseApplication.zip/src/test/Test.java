package test;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import model.Lead;
import model.LeadRepository;

public class Test {
	public static void main(String[] args) throws FileNotFoundException {
		LeadRepository leadRepository = 
				new LeadRepository("D:\\Eclipse Workspace\\EnterpriseApplication\\TestData\\leads.csv");
		ArrayList<Lead> leads = leadRepository.read();
		System.out.println(leads.size());
		for(Lead lead:leads) {
			System.out.println(lead);
		}
	}
}
