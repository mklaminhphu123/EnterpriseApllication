package model;

import java.util.Date;

public class Interaction {
	private String id;
	private Date dateOfInteraction;
	private String leadID;
	private String email;
	private Potential potential;
	

}

