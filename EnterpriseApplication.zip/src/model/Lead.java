package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Lead
{
    //Data Field
	private String id;
    private String name;
    private Date dob;
    private boolean gender;
    private String phone;
    private String email;
    private String address;
    
    



    //Constructor
    public Lead(String id, String name, Date dob, boolean gender, String phone, String email, String address)
    {
    	this.id = id;
        this.name = name;
        this.dob = dob;
        this.gender = gender;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }
    
    public Lead(String name, Date dob, boolean gender, String phone, String email, String address)
    {
    	//TODO: generate new id
    	//this.id = generate ID
        this.name = name;
        this.dob = dob;
        this.gender = gender;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }
    
    @Override
    public String toString() {
    	DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");  
    	
    	// TODO Auto-generated method stub
    	return "Name: " + name + "\n" 
    			+ "ID: "+ id + "\n"
    			+ "Date of Birth: " + dateFormat.format(dob) + "\n"
    			+ "Gender: " + gender + "\n"
    			+ "Phone number: "+ phone  + "\n"
    			+ "Email "+ email + "\n"
    			+ "Address: " +  address + "\n"
    			;
    }
    
    /*
    //Get 'n' Set
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public Date getDob()
    {
        return dob;
    }
    public void setDob(Date dob)
    {
        this.dob = dob;
    }

    public boolean isGender()
    {
        return gender;
    }
    public void setGender(boolean gender)
    {
        this.gender = gender;
    }

    public long getPhone()
    {
        return phone;
    }
    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getEmail()
    {
        return email;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getAddress()
    {
        return address;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }

     */

    //Method
//    public static void leads() throws Exception
//    {
//        Scanner sc = new Scanner(System.in);
//
//        System.out.println("Pls input the requirement: ");
//
//        System.out.print("What is your phone number: ");
//        String phone = sc.nextLine();
//        phoneList[n+1] = phone;
//
//        System.out.print("What is your email: ");
//        String email = sc.nextLine();
//        emailList[n+1] = email;
//
//        System.out.print("What is your address: ");
//        String address = sc.nextLine();
//        addressList[n+1] = address;
//
//        System.out.print("What is your name: ");
//        String name = sc.nextLine();
//        nameList[n+1] = name;
//
//        System.out.print("When is your birthday(dd-mm-yyyy): ");
//        String dob = sc.nextLine();
//        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
//        Date bDay = format.parse(dob);
//        System.out.println(format.format(bDay));
//        dobList[n+1] = bDay;
//
//        System.out.print("Gender(Just said True or False): ");
//        boolean gender = sc.nextBoolean();
//        genderList[n+1] = gender;
//
//        System.out.printf("lead_%03d,%s,%td-%tm-%tY,%b,%s,%s,%s%n", n, nameList[n+1], dobList[n+1], dobList[n+1], dobList[n+1], genderList[n+1], phoneList[n+1], emailList[n+1], addressList[n+1]);
//
//        System.out.println();
//
//        //sc.close();
//    }

   

    private static boolean equals(String s, String s1)
    {
        if (s == s1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}