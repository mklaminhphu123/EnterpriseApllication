package model;

public enum Potential {
	Positive,
	Neutral,
	Negative,
}
